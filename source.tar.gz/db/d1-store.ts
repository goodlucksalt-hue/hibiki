import { and, desc, eq, sql } from "drizzle-orm";
import { getDb } from ".";
import { words } from "./schema";
import type { ReviewResult, WordInput, WordPatch, WordStore } from "./types";

export const d1Store: WordStore = {
  async list() {
    return getDb().select().from(words).orderBy(desc(words.addedAt), desc(words.id));
  },

  async findDuplicate(word, reading) {
    const [existing] = await getDb()
      .select()
      .from(words)
      .where(and(eq(words.word, word), eq(words.reading, reading)))
      .limit(1);
    return existing;
  },

  async create(input: WordInput) {
    const [created] = await getDb().insert(words).values(input).returning();
    return created;
  },

  async update(id: number, patch: WordPatch) {
    const [updated] = await getDb()
      .update(words)
      .set({ ...patch, updatedAt: new Date().toISOString() })
      .where(eq(words.id, id))
      .returning();
    return updated;
  },

  async remove(id: number) {
    await getDb().delete(words).where(eq(words.id, id));
  },

  async recordReview(id: number, result: ReviewResult) {
    const now = new Date().toISOString();
    const [updated] = await getDb()
      .update(words)
      .set({
        reviewCount: sql`${words.reviewCount} + 1`,
        knewCount: result === "knew" ? sql`${words.knewCount} + 1` : words.knewCount,
        fuzzyCount: result === "fuzzy" ? sql`${words.fuzzyCount} + 1` : words.fuzzyCount,
        missedCount: result === "missed" ? sql`${words.missedCount} + 1` : words.missedCount,
        lastResult: result,
        lastReviewedAt: now,
        updatedAt: now,
        status: result === "knew" ? "review" : "learning",
        ...(result === "knew" ? {} : { isFocus: true }),
      })
      .where(eq(words.id, id))
      .returning();
    return updated;
  },
};
