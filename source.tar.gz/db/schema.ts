import { sql } from "drizzle-orm";
import { index, integer, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";

export const words = sqliteTable(
  "words",
  {
    id: integer("id").primaryKey({ autoIncrement: true }),
    word: text("word").notNull(),
    reading: text("reading").notNull(),
    meaning: text("meaning").notNull(),
    exampleJa: text("example_ja").notNull().default(""),
    exampleZh: text("example_zh").notNull().default(""),
    addedAt: text("added_at").notNull().default(sql`CURRENT_TIMESTAMP`),
    updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
    lastReviewedAt: text("last_reviewed_at"),
    reviewCount: integer("review_count").notNull().default(0),
    knewCount: integer("knew_count").notNull().default(0),
    fuzzyCount: integer("fuzzy_count").notNull().default(0),
    missedCount: integer("missed_count").notNull().default(0),
    status: text("status", { enum: ["new", "learning", "review"] }).notNull().default("new"),
    isFocus: integer("is_focus", { mode: "boolean" }).notNull().default(false),
    lastResult: text("last_result", { enum: ["knew", "fuzzy", "missed"] }),
  },
  (table) => [
    uniqueIndex("idx_words_word_reading").on(table.word, table.reading),
    index("idx_words_focus_last_reviewed").on(table.isFocus, table.lastReviewedAt),
  ],
);
