export type ReviewResult = "knew" | "fuzzy" | "missed";
export type LearningStatus = "new" | "learning" | "review";

export type WordRow = {
  id: number;
  word: string;
  reading: string;
  meaning: string;
  exampleJa: string;
  exampleZh: string;
  addedAt: string;
  updatedAt: string;
  lastReviewedAt: string | null;
  reviewCount: number;
  knewCount: number;
  fuzzyCount: number;
  missedCount: number;
  status: LearningStatus;
  isFocus: boolean;
  lastResult: ReviewResult | null;
};

export type WordInput = Pick<WordRow, "word" | "reading" | "meaning" | "exampleJa" | "exampleZh">;

export type WordPatch = Partial<WordInput> & { isFocus?: boolean };

export interface WordStore {
  list(): Promise<WordRow[]>;
  findDuplicate(word: string, reading: string): Promise<WordRow | undefined>;
  create(input: WordInput): Promise<WordRow>;
  update(id: number, patch: WordPatch): Promise<WordRow | undefined>;
  remove(id: number): Promise<void>;
  recordReview(id: number, result: ReviewResult): Promise<WordRow | undefined>;
}
