import type { WordStore } from "./types";

let storePromise: Promise<WordStore> | undefined;

export function getWordStore(): Promise<WordStore> {
  storePromise ??= process.env.DATABASE_URL
    ? import("./postgres-store").then(({ postgresStore }) => postgresStore)
    : import("./d1-store").then(({ d1Store }) => d1Store);
  return storePromise;
}

export type { ReviewResult, WordInput, WordPatch, WordRow } from "./types";
