declare module "pg" {
  type QueryResult<Row> = { rows: Row[] };
  type Client = {
    query<Row = Record<string, unknown>>(text: string, values?: unknown[]): Promise<QueryResult<Row>>;
    release(): void;
  };
  class Pool {
    constructor(config?: { connectionString?: string });
    query<Row = Record<string, unknown>>(text: string, values?: unknown[]): Promise<QueryResult<Row>>;
    connect(): Promise<Client>;
  }
  const pg: { Pool: typeof Pool };
  export default pg;
}
