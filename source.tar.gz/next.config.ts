import type { NextConfig } from "next";
import path from "node:path";

const nextConfig: NextConfig = {
  output: process.env.RAILWAY_BUILD === "1" ? "standalone" : undefined,
  webpack(config, { webpack }) {
    if (process.env.RAILWAY_BUILD === "1") {
      config.plugins.push(
        new webpack.NormalModuleReplacementPlugin(
          /^cloudflare:workers$/,
          path.resolve("db/cloudflare-workers-stub.ts"),
        ),
      );
    }
    return config;
  },
};

export default nextConfig;
