ALTER TABLE `words` ADD `example_ja` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `words` ADD `example_zh` text DEFAULT '' NOT NULL;