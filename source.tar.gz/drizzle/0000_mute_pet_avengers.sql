CREATE TABLE `words` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`word` text NOT NULL,
	`reading` text NOT NULL,
	`meaning` text NOT NULL,
	`added_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`last_reviewed_at` text,
	`review_count` integer DEFAULT 0 NOT NULL,
	`knew_count` integer DEFAULT 0 NOT NULL,
	`fuzzy_count` integer DEFAULT 0 NOT NULL,
	`missed_count` integer DEFAULT 0 NOT NULL,
	`status` text DEFAULT 'new' NOT NULL,
	`is_focus` integer DEFAULT false NOT NULL,
	`last_result` text
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_words_word_reading` ON `words` (`word`,`reading`);--> statement-breakpoint
CREATE INDEX `idx_words_focus_last_reviewed` ON `words` (`is_focus`,`last_reviewed_at`);