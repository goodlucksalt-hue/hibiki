"use client";

import {
  FormEvent,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import {
  ArrowLeft,
  BookOpen,
  Check,
  ChevronRight,
  CircleAlert,
  Clock3,
  Ear,
  FileSpreadsheet,
  Flame,
  House,
  Library,
  Pencil,
  Play,
  Plus,
  Search,
  Speaker,
  Star,
  Trash2,
  Upload,
  Volume2,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Toaster } from "@/components/ui/sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

type Result = "knew" | "fuzzy" | "missed";
type View = "home" | "add" | "import" | "library" | "focus" | "training";
type TrainingMode = "normal" | "focus";
type TrainingPhase = "listen" | "answer";

type Word = {
  id: number;
  word: string;
  reading: string;
  meaning: string;
  exampleJa: string;
  exampleZh: string;
  addedAt: string;
  updatedAt: string;
  lastReviewedAt: string | null;
  reviewCount: number;
  knewCount: number;
  fuzzyCount: number;
  missedCount: number;
  status: "new" | "learning" | "review";
  isFocus: boolean;
  lastResult: Result | null;
};

type Draft = {
  word: string;
  reading: string;
  meaning: string;
  exampleJa: string;
  exampleZh: string;
};

type ImportRow = Draft & {
  key: string;
  issue?: string;
  duplicate?: Word;
  action: "keep" | "update" | "skip";
};

const EMPTY: Draft = {
  word: "",
  reading: "",
  meaning: "",
  exampleJa: "",
  exampleZh: "",
};

const resultLabel: Record<Result, string> = {
  knew: "会",
  fuzzy: "模糊",
  missed: "完全不会",
};

function exampleFor(word: Word) {
  return {
    ja: word.exampleJa || `「${word.word}」という言葉を今日覚えました。`,
    zh: word.exampleZh || `今天记住了“${word.word}”这个词。`,
  };
}

function formatDate(value: string | null) {
  if (!value) return "尚未复习";
  return new Intl.DateTimeFormat("zh-CN", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date(value));
}

function weightedPick(items: Word[], recent: number[]) {
  const eligible = items.filter((item) => !recent.includes(item.id));
  const pool = eligible.length
    ? eligible
    : items.filter((item) => item.id !== recent[0]);
  if (!pool.length) return null;

  const weights = pool.map((item) => {
    const base =
      item.lastResult === "missed"
        ? 6
        : item.lastResult === "fuzzy"
          ? 4
          : item.lastResult === "knew"
            ? 1.25
            : 2.2;
    return base * (item.isFocus ? 1.55 : 1);
  });

  let target = Math.random() * weights.reduce((sum, value) => sum + value, 0);
  for (let index = 0; index < pool.length; index += 1) {
    target -= weights[index];
    if (target <= 0) return pool[index];
  }
  return pool[pool.length - 1];
}

function parseDelimited(text: string) {
  const firstLine = text.split(/\r?\n/, 1)[0] ?? "";
  const delimiter = ["\t", ",", ";"].sort(
    (a, b) => firstLine.split(b).length - firstLine.split(a).length,
  )[0];
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = "";
  let quoted = false;

  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    if (char === '"' && quoted && text[index + 1] === '"') {
      cell += '"';
      index += 1;
    } else if (char === '"') {
      quoted = !quoted;
    } else if (char === delimiter && !quoted) {
      row.push(cell.trim());
      cell = "";
    } else if ((char === "\n" || char === "\r") && !quoted) {
      if (char === "\r" && text[index + 1] === "\n") index += 1;
      row.push(cell.trim());
      if (row.some(Boolean)) rows.push(row);
      row = [];
      cell = "";
    } else {
      cell += char;
    }
  }

  row.push(cell.trim());
  if (row.some(Boolean)) rows.push(row);
  return rows;
}

function rowsToDrafts(rows: unknown[][]): Draft[] {
  if (!rows.length) return [];
  const normalized = rows.map((row) =>
    row.map((cell) => String(cell ?? "").trim()),
  );
  const aliases = {
    word: ["日语单词", "日文单词", "单词", "日语", "word", "japanese"],
    reading: ["假名/读音", "假名", "读音", "かな", "reading", "kana"],
    meaning: ["中文释义", "释义", "中文", "意思", "meaning", "chinese"],
    exampleJa: ["日语例句", "例句", "example", "exampleja"],
    exampleZh: ["例句中文", "例句翻译", "翻译", "examplezh"],
  };
  const header = normalized[0].map((value) => value.toLowerCase());
  const findIndex = (values: string[]) =>
    header.findIndex((value) => values.includes(value));
  const indexes = {
    word: findIndex(aliases.word),
    reading: findIndex(aliases.reading),
    meaning: findIndex(aliases.meaning),
    exampleJa: findIndex(aliases.exampleJa),
    exampleZh: findIndex(aliases.exampleZh),
  };
  const hasHeader =
    indexes.word >= 0 && indexes.reading >= 0 && indexes.meaning >= 0;
  const map = hasHeader
    ? indexes
    : { word: 0, reading: 1, meaning: 2, exampleJa: 3, exampleZh: 4 };

  return normalized.slice(hasHeader ? 1 : 0).map((row) => ({
    word: row[map.word] ?? "",
    reading: row[map.reading] ?? "",
    meaning: row[map.meaning] ?? "",
    exampleJa: map.exampleJa >= 0 ? (row[map.exampleJa] ?? "") : "",
    exampleZh: map.exampleZh >= 0 ? (row[map.exampleZh] ?? "") : "",
  }));
}

export default function Home() {
  const [view, setView] = useState<View>("home");
  const [words, setWords] = useState<Word[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [draft, setDraft] = useState<Draft>(EMPTY);
  const [saving, setSaving] = useState(false);
  const [duplicate, setDuplicate] = useState<Word | null>(null);
  const [editWord, setEditWord] = useState<Word | null>(null);
  const [deleteWord, setDeleteWord] = useState<Word | null>(null);
  const [search, setSearch] = useState("");
  const [importRows, setImportRows] = useState<ImportRow[]>([]);
  const [importName, setImportName] = useState("");
  const [importing, setImporting] = useState(false);
  const [mode, setMode] = useState<TrainingMode>("normal");
  const [phase, setPhase] = useState<TrainingPhase>("listen");
  const [activeIds, setActiveIds] = useState<number[]>([]);
  const [current, setCurrent] = useState<Word | null>(null);
  const [recent, setRecent] = useState<number[]>([]);
  const [played, setPlayed] = useState(false);
  const [rated, setRated] = useState<Result | null>(null);
  const [rating, setRating] = useState(false);
  const [ttsError, setTtsError] = useState("");
  const [audioStatus, setAudioStatus] = useState<"idle" | "playing">("idle");
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const loadWords = useCallback(async () => {
    try {
      setLoadError("");
      const response = await fetch("/api/words", { cache: "no-store" });
      const data = (await response.json()) as { error?: string; words: Word[] };
      if (!response.ok) throw new Error(data.error);
      setWords(data.words);
    } catch (error) {
      setLoadError(
        error instanceof Error ? error.message : "词库暂时无法读取。",
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadWords();
  }, [loadWords]);

  useEffect(() => {
    return () => {
      if (typeof window !== "undefined" && "speechSynthesis" in window) {
        window.speechSynthesis.cancel();
      }
      utteranceRef.current = null;
    };
  }, [current?.id]);

  useEffect(() => {
    const context = (
      document as Document & {
        modelContext?: {
          registerTool?: (
            tool: unknown,
            options?: { signal: AbortSignal },
          ) => void | Promise<void>;
        };
      }
    ).modelContext;
    if (!context?.registerTool) return;

    const lifecycle = new AbortController();
    void Promise.resolve(
      context.registerTool(
        {
          name: "add_japanese_word",
          title: "添加日语单词",
          description: "向 Hibiki 添加一个日语单词并自动检查重复。",
          inputSchema: {
            type: "object",
            properties: {
              word: { type: "string" },
              reading: { type: "string" },
              meaning: { type: "string" },
              exampleJa: { type: "string" },
              exampleZh: { type: "string" },
            },
            required: ["word", "reading", "meaning"],
            additionalProperties: false,
          },
          annotations: { readOnlyHint: false, untrustedContentHint: false },
          execute: async (input: unknown) => {
            const response = await fetch("/api/words", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(input),
            });
            const data = (await response.json()) as {
              error?: string;
              code?: string;
              word: Word;
            };
            if (!response.ok) {
              throw new Error(data.error ?? data.code ?? "添加失败");
            }
            await loadWords();
            return { id: data.word.id, saved: true };
          },
        },
        { signal: lifecycle.signal },
      ),
    ).catch(() => undefined);

    return () => lifecycle.abort();
  }, [loadWords]);

  const stats = useMemo(
    () => ({
      total: words.length,
      focus: words.filter((word) => word.isFocus).length,
      reviewed: words.filter((word) => word.reviewCount > 0).length,
    }),
    [words],
  );

  const filtered = useMemo(() => {
    const query = search.trim().toLowerCase();
    return words.filter(
      (item) =>
        !query ||
        [item.word, item.reading, item.meaning].some((value) =>
          value.toLowerCase().includes(query),
        ),
    );
  }, [words, search]);

  async function addWord(action?: "keep" | "update") {
    setSaving(true);
    try {
      const response = await fetch("/api/words", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...draft, duplicateAction: action }),
      });
      const data = (await response.json()) as {
        code?: string;
        existing?: Word;
        updated?: boolean;
        error?: string;
      };
      if (
        response.status === 409 &&
        data.code === "duplicate_conflict" &&
        data.existing &&
        !action
      ) {
        setDuplicate(data.existing);
        return;
      }
      if (response.status === 409) {
        toast.info("这个单词和读音已经在词库中。未创建重复记录。");
        setDuplicate(null);
        return;
      }
      if (!response.ok) throw new Error(data.error);
      toast.success(data.updated ? "释义和例句已更新" : "单词已加入词库");
      setDraft(EMPTY);
      setDuplicate(null);
      await loadWords();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "保存失败");
    } finally {
      setSaving(false);
    }
  }

  async function updateWord(
    id: number,
    patch: Partial<Draft & { isFocus: boolean }>,
  ) {
    const response = await fetch(`/api/words/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(patch),
    });
    const data = (await response.json()) as { error?: string; word: Word };
    if (!response.ok) throw new Error(data.error);
    setWords((items) =>
      items.map((item) => (item.id === id ? data.word : item)),
    );
    return data.word;
  }

  async function parseFile(file: File) {
    setImportName(file.name);
    setImportRows([]);
    try {
      let drafts: Draft[] = [];
      if (/\.xlsx?$/i.test(file.name)) {
        const XLSX = await import("xlsx");
        const workbook = XLSX.read(await file.arrayBuffer(), { type: "array" });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        drafts = rowsToDrafts(
          XLSX.utils.sheet_to_json<unknown[]>(sheet, {
            header: 1,
            raw: false,
          }),
        );
      } else if (/\.(csv|txt)$/i.test(file.name)) {
        drafts = rowsToDrafts(parseDelimited(await file.text()));
      } else {
        throw new Error("请选择 CSV、XLSX 或 TXT 文件。");
      }

      const existingMap = new Map(
        words.map((item) => [`${item.word}\u0000${item.reading}`, item]),
      );
      const seen = new Set<string>();
      setImportRows(
        drafts.map((item, index) => {
          const identity = `${item.word}\u0000${item.reading}`;
          const duplicateWord = existingMap.get(identity);
          const issue =
            !item.word || !item.reading || !item.meaning
              ? "缺少必填字段"
              : seen.has(identity)
                ? "文件内重复"
                : undefined;
          seen.add(identity);
          return {
            ...item,
            key: `${index}-${identity}`,
            issue,
            duplicate: duplicateWord,
            action: issue ? "skip" : duplicateWord ? "keep" : "update",
          };
        }),
      );
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "文件解析失败");
    }
  }

  async function confirmImport() {
    setImporting(true);
    try {
      const response = await fetch("/api/words/import", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rows: importRows }),
      });
      const data = (await response.json()) as {
        error?: string;
        added: number;
        updated: number;
      };
      if (!response.ok) throw new Error(data.error);
      toast.success(
        `已新增 ${data.added} 词${data.updated ? `，更新 ${data.updated} 词` : ""}`,
      );
      setImportRows([]);
      setImportName("");
      await loadWords();
      setView("library");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "导入失败");
    } finally {
      setImporting(false);
    }
  }

  function beginTraining(nextMode: TrainingMode) {
    const pool = words.filter(
      (item) => nextMode === "normal" || item.isFocus,
    );
    setMode(nextMode);
    setActiveIds(pool.map((item) => item.id));
    setRecent([]);
    setPlayed(false);
    setRated(null);
    setPhase("listen");
    setTtsError("");
    setAudioStatus("idle");
    setCurrent(weightedPick(pool, []));
    setView("training");
  }

  function playCurrent() {
    if (!current) return;
    if (!("speechSynthesis" in window)) {
      setTtsError(
        "当前浏览器不支持语音朗读。请使用最新版 Safari、Chrome 或 Edge。",
      );
      return;
    }

    const synth = window.speechSynthesis;
    const availableVoices = synth.getVoices();
    const japaneseVoices = availableVoices.filter((voice) =>
      /^ja(?:-|_)/i.test(voice.lang),
    );
    if (availableVoices.length > 0 && japaneseVoices.length === 0) {
      setTtsError(
        "这台设备没有可用的日语语音。请在系统设置中下载日语语音后重试。",
      );
      return;
    }

    const preferredVoice =
      japaneseVoices.find((voice) =>
        /kyoko|otoya|o-ren|nanami|google.*日本|siri/i.test(voice.name),
      ) ??
      japaneseVoices.find((voice) => voice.localService) ??
      japaneseVoices[0];

    if (synth.speaking || synth.pending) synth.cancel();
    const utterance = new SpeechSynthesisUtterance(current.reading || current.word);
    utterance.lang = "ja-JP";
    utterance.rate = 0.88;
    utterance.pitch = 1;
    if (preferredVoice) utterance.voice = preferredVoice;
    utterance.onstart = () => {
      setAudioStatus("playing");
      setTtsError("");
    };
    utterance.onend = () => setAudioStatus("idle");
    utterance.onerror = (event) => {
      if (event.error === "interrupted" || event.error === "canceled") return;
      setAudioStatus("idle");
      setTtsError("日语语音播放失败，请检查设备音量或语音设置后重试。");
    };

    utteranceRef.current = utterance;
    setPlayed(true);
    setTtsError("");
    synth.speak(utterance);
    if (synth.paused) synth.resume();
  }

  async function rateCurrent(result: Result) {
    if (!current || rating || phase !== "listen") return;
    setRating(true);
    try {
      const response = await fetch(`/api/words/${current.id}/review`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ result }),
      });
      const data = (await response.json()) as { error?: string; word: Word };
      if (!response.ok) throw new Error(data.error);
      setWords((items) =>
        items.map((item) => (item.id === current.id ? data.word : item)),
      );
      setCurrent(data.word);
      setRated(result);
      if (result === "knew") {
        setActiveIds((ids) => ids.filter((id) => id !== current.id));
      }
      if ("speechSynthesis" in window) window.speechSynthesis.cancel();
      setAudioStatus("idle");
      setPhase("answer");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "复习结果保存失败");
    } finally {
      setRating(false);
    }
  }

  function nextWord() {
    if (!current) return;
    if ("speechSynthesis" in window) window.speechSynthesis.cancel();
    utteranceRef.current = null;
    const latestRecent = [current.id, ...recent].slice(0, 2);
    const candidates = words.filter(
      (item) =>
        activeIds.includes(item.id) && (mode === "normal" || item.isFocus),
    );
    setRecent(latestRecent);
    setCurrent(weightedPick(candidates, latestRecent));
    setPlayed(false);
    setRated(null);
    setRating(false);
    setPhase("listen");
    setTtsError("");
    setAudioStatus("idle");
  }

  const previewStats = useMemo(
    () => ({
      recognized: importRows.length,
      added: importRows.filter((row) => !row.issue && !row.duplicate).length,
      duplicate: importRows.filter(
        (row) => Boolean(row.duplicate) || row.issue === "文件内重复",
      ).length,
      issues: importRows.filter((row) => Boolean(row.issue)).length,
    }),
    [importRows],
  );

  if (view === "training") {
    return (
      <TrainingScreen
        mode={mode}
        phase={phase}
        current={current}
        activeCount={activeIds.length}
        played={played}
        rated={rated}
        rating={rating}
        audioStatus={audioStatus}
        ttsError={ttsError}
        onBack={() => setView("home")}
        onPlay={playCurrent}
        onRate={rateCurrent}
        onNext={nextWord}
      />
    );
  }

  return (
    <div className="min-h-dvh bg-[#FAF9F7] text-[#3F3D43]">
      <Toaster position="top-center" richColors />
      <header className="sticky top-0 z-30 border-b border-[#ECE9EF]/80 bg-[#FAF9F7]/90 backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-5xl items-center justify-between px-4 sm:px-7">
          <button
            className="flex items-center gap-2.5"
            onClick={() => setView("home")}
            aria-label="回到首页"
          >
            <span className="grid size-9 place-items-center rounded-[13px] bg-[#F0ECF8] text-[#796CAD]">
              <Ear className="size-5" />
            </span>
            <span className="text-lg font-semibold tracking-tight">Hibiki</span>
          </button>
          <span className="rounded-full bg-white px-3 py-1.5 text-sm text-[#77727D] shadow-[0_1px_4px_rgba(64,54,78,.06)]">
            {stats.total} 词
          </span>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-4 pb-28 pt-7 sm:px-7 sm:pb-12">
        {loadError && (
          <div className="mb-5 flex items-center justify-between gap-3 rounded-2xl bg-[#FFF1F0] p-4 text-[#9D4F4A]">
            <span>{loadError}</span>
            <Button variant="outline" onClick={() => void loadWords()}>
              重试
            </Button>
          </div>
        )}

        {view === "home" && (
          <HomeView
            stats={stats}
            loading={loading}
            onTrain={() => beginTraining("normal")}
            onFocus={() => beginTraining("focus")}
            onNavigate={setView}
          />
        )}
        {view === "add" && (
          <AddView
            draft={draft}
            setDraft={setDraft}
            saving={saving}
            onSubmit={(event) => {
              event.preventDefault();
              void addWord();
            }}
          />
        )}
        {view === "import" && (
          <ImportView
            rows={importRows}
            fileName={importName}
            stats={previewStats}
            fileRef={fileRef}
            onFile={(file) => void parseFile(file)}
            onRows={setImportRows}
            onConfirm={() => void confirmImport()}
            importing={importing}
          />
        )}
        {view === "library" && (
          <WordList
            title="总词库"
            description="所有已添加的词和学习记录"
            words={filtered}
            search={search}
            setSearch={setSearch}
            onEdit={setEditWord}
            onDelete={setDeleteWord}
            onFocus={async (word) => {
              try {
                await updateWord(word.id, { isFocus: !word.isFocus });
                toast.success(
                  word.isFocus ? "已移出重点词池" : "已加入重点词池",
                );
              } catch (error) {
                toast.error(error instanceof Error ? error.message : "更新失败");
              }
            }}
          />
        )}
        {view === "focus" && (
          <WordList
            title="重点词池"
            description="曾经模糊或完全不会的词会长期保留在这里"
            words={filtered.filter((item) => item.isFocus)}
            search={search}
            setSearch={setSearch}
            onEdit={setEditWord}
            onDelete={setDeleteWord}
            onFocus={async (word) => {
              try {
                await updateWord(word.id, { isFocus: false });
                toast.success("已移出重点词池，学习记录仍然保留");
              } catch (error) {
                toast.error(error instanceof Error ? error.message : "更新失败");
              }
            }}
            focusOnly
            onTrain={() => beginTraining("focus")}
          />
        )}
      </main>

      <BottomNav view={view} onNavigate={setView} />

      <Dialog
        open={Boolean(duplicate)}
        onOpenChange={(open) => !open && setDuplicate(null)}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>发现相同单词与读音</DialogTitle>
            <DialogDescription>
              词库中的释义与本次输入不同，请选择处理方式。
            </DialogDescription>
          </DialogHeader>
          {duplicate && (
            <div className="grid gap-3 rounded-2xl bg-[#F7F5F8] p-4 text-sm">
              <div>
                <span className="text-[#827D87]">原释义</span>
                <p className="mt-1 font-medium">{duplicate.meaning}</p>
              </div>
              <div>
                <span className="text-[#827D87]">新释义</span>
                <p className="mt-1 font-medium">{draft.meaning}</p>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDuplicate(null)}>
              取消
            </Button>
            <Button variant="secondary" onClick={() => void addWord("keep")}>
              保留原词
            </Button>
            <Button onClick={() => void addWord("update")}>更新内容</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <EditDialog
        word={editWord}
        onClose={() => setEditWord(null)}
        onSave={async (id, changes) => {
          try {
            await updateWord(id, changes);
            toast.success("单词已更新");
            setEditWord(null);
          } catch (error) {
            toast.error(error instanceof Error ? error.message : "更新失败");
          }
        }}
      />

      <AlertDialog
        open={Boolean(deleteWord)}
        onOpenChange={(open) => !open && setDeleteWord(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>删除“{deleteWord?.word}”？</AlertDialogTitle>
            <AlertDialogDescription>
              这个词及全部学习记录都会被永久删除，无法撤销。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction
              variant="destructive"
              onClick={async () => {
                if (!deleteWord) return;
                const response = await fetch(`/api/words/${deleteWord.id}`, {
                  method: "DELETE",
                });
                if (response.ok) {
                  setWords((items) =>
                    items.filter((item) => item.id !== deleteWord.id),
                  );
                  toast.success("已删除");
                } else {
                  toast.error("删除失败");
                }
                setDeleteWord(null);
              }}
            >
              确认删除
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function HomeView({
  stats,
  loading,
  onTrain,
  onFocus,
  onNavigate,
}: {
  stats: { total: number; focus: number; reviewed: number };
  loading: boolean;
  onTrain: () => void;
  onFocus: () => void;
  onNavigate: (view: View) => void;
}) {
  return (
    <div className="space-y-7">
      <section className="overflow-hidden rounded-[30px] bg-[linear-gradient(145deg,#FFFFFF_0%,#F6F2FB_68%,#FFF9E9_100%)] p-6 shadow-[0_12px_36px_rgba(74,62,90,.07)] sm:p-9">
        <div className="mb-10 flex items-start justify-between gap-6">
          <div>
            <p className="text-sm text-[#85808A]">今日听力训练</p>
            <h1 className="mt-3 max-w-md text-3xl font-semibold leading-[1.25] tracking-[-0.025em] text-[#454149] sm:text-4xl">
              先听见，
              <br />
              再想起来。
            </h1>
          </div>
          <div className="grid size-14 shrink-0 place-items-center rounded-[20px] bg-[#EEE9F7] text-[#7B6EAF]">
            <Speaker className="size-6" />
          </div>
        </div>
        <Button
          disabled={loading || stats.total === 0}
          onClick={onTrain}
          className="h-14 w-full rounded-2xl bg-[#8577B9] text-base font-medium text-white shadow-none hover:bg-[#776AA9]"
        >
          <Play className="size-4 fill-current" />
          开始普通复习
        </Button>
        {stats.total === 0 && (
          <p className="mt-3 text-center text-sm text-[#8C8790]">
            先添加几个词，就可以开始训练
          </p>
        )}
      </section>

      <section className="grid grid-cols-3 gap-3">
        <Stat value={stats.total} label="总词数" />
        <Stat value={stats.focus} label="重点词" accent />
        <Stat value={stats.reviewed} label="已复习" />
      </section>

      <section className="grid gap-3 sm:grid-cols-2">
        <ActionCard
          icon={<Flame />}
          title="重点复习"
          detail={stats.focus ? `只练 ${stats.focus} 个薄弱词` : "暂无重点词"}
          onClick={onFocus}
          disabled={!stats.focus}
          accent
        />
        <ActionCard
          icon={<Plus />}
          title="添加单词"
          detail="手动录入一个新词"
          onClick={() => onNavigate("add")}
        />
        <ActionCard
          icon={<FileSpreadsheet />}
          title="导入词库"
          detail="CSV、XLSX 或 TXT"
          onClick={() => onNavigate("import")}
        />
        <ActionCard
          icon={<Library />}
          title="总词库"
          detail="搜索、编辑和管理"
          onClick={() => onNavigate("library")}
        />
      </section>
    </div>
  );
}

function Stat({
  value,
  label,
  accent,
}: {
  value: number;
  label: string;
  accent?: boolean;
}) {
  return (
    <div
      className={`rounded-[20px] p-4 ${accent ? "bg-[#F2EFF9]" : "bg-white"}`}
    >
      <strong className="block text-2xl font-semibold text-[#504C55]">
        {value}
      </strong>
      <span className="mt-1 block text-sm text-[#8A858E]">{label}</span>
    </div>
  );
}

function ActionCard({
  icon,
  title,
  detail,
  onClick,
  disabled,
  accent,
}: {
  icon: React.ReactNode;
  title: string;
  detail: string;
  onClick: () => void;
  disabled?: boolean;
  accent?: boolean;
}) {
  return (
    <button
      disabled={disabled}
      onClick={onClick}
      className="group flex min-h-24 items-center gap-4 rounded-[22px] bg-white p-4 text-left shadow-[0_4px_18px_rgba(72,63,82,.045)] transition hover:-translate-y-0.5 hover:shadow-[0_8px_24px_rgba(72,63,82,.08)] disabled:cursor-not-allowed disabled:opacity-45"
    >
      <span
        className={`grid size-12 shrink-0 place-items-center rounded-2xl ${accent ? "bg-[#FFF7DF] text-[#9A8350]" : "bg-[#F2EFF8] text-[#7C70AA]"}`}
      >
        {icon}
      </span>
      <span className="min-w-0 flex-1">
        <strong className="block font-medium text-[#4C4850]">{title}</strong>
        <span className="mt-1 block text-sm text-[#8A858E]">{detail}</span>
      </span>
      <ChevronRight className="size-5 text-[#B2ADB6] transition group-hover:translate-x-0.5" />
    </button>
  );
}

function AddView({
  draft,
  setDraft,
  saving,
  onSubmit,
}: {
  draft: Draft;
  setDraft: (value: Draft) => void;
  saving: boolean;
  onSubmit: (event: FormEvent) => void;
}) {
  return (
    <PageShell
      eyebrow="手动添加"
      title="添加一个新词"
      description="保存时会按“日语单词 + 读音”自动检查重复。例句可以稍后补充。"
    >
      <form
        onSubmit={onSubmit}
        className="space-y-5 rounded-[26px] bg-white p-5 shadow-[0_6px_28px_rgba(72,63,82,.055)] sm:p-7"
      >
        <Field
          label="日语单词"
          value={draft.word}
          placeholder="広まる"
          onChange={(word) => setDraft({ ...draft, word })}
          lang="ja"
        />
        <Field
          label="假名 / 读音"
          value={draft.reading}
          placeholder="ひろまる"
          onChange={(reading) => setDraft({ ...draft, reading })}
          lang="ja"
        />
        <div className="space-y-2">
          <Label htmlFor="meaning">中文释义</Label>
          <Textarea
            id="meaning"
            required
            value={draft.meaning}
            onChange={(event) =>
              setDraft({ ...draft, meaning: event.target.value })
            }
            placeholder="扩大；传播；普及；蔓延"
            className="min-h-24 rounded-2xl border-[#E9E5EC] text-base shadow-none"
          />
        </div>
        <Field
          label="日语例句（可选）"
          value={draft.exampleJa}
          placeholder="うわさが全国に広まる。"
          onChange={(exampleJa) => setDraft({ ...draft, exampleJa })}
          lang="ja"
          required={false}
        />
        <Field
          label="例句中文（可选）"
          value={draft.exampleZh}
          placeholder="谣言传遍全国。"
          onChange={(exampleZh) => setDraft({ ...draft, exampleZh })}
          required={false}
        />
        <Button
          disabled={saving}
          className="h-12 w-full rounded-2xl bg-[#8577B9] text-base font-medium shadow-none hover:bg-[#776AA9]"
        >
          {saving ? "正在保存…" : "保存到词库"}
        </Button>
      </form>
    </PageShell>
  );
}

function Field({
  label,
  value,
  placeholder,
  onChange,
  lang,
  required = true,
}: {
  label: string;
  value: string;
  placeholder: string;
  onChange: (value: string) => void;
  lang?: string;
  required?: boolean;
}) {
  const id = label.replace(/\s/g, "-");
  return (
    <div className="space-y-2">
      <Label htmlFor={id}>{label}</Label>
      <Input
        id={id}
        lang={lang}
        required={required}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        className="h-12 rounded-2xl border-[#E9E5EC] bg-[#FDFCFC] text-base shadow-none"
      />
    </div>
  );
}

function ImportView({
  rows,
  fileName,
  stats,
  fileRef,
  onFile,
  onRows,
  onConfirm,
  importing,
}: {
  rows: ImportRow[];
  fileName: string;
  stats: {
    recognized: number;
    added: number;
    duplicate: number;
    issues: number;
  };
  fileRef: React.RefObject<HTMLInputElement | null>;
  onFile: (file: File) => void;
  onRows: (rows: ImportRow[]) => void;
  onConfirm: () => void;
  importing: boolean;
}) {
  return (
    <PageShell
      eyebrow="批量导入"
      title="导入整理好的词表"
      description="支持 CSV、XLSX、TXT。前三列为单词、读音、释义；第 4、5 列可选填日语例句和中文翻译。"
    >
      <input
        ref={fileRef}
        className="sr-only"
        type="file"
        accept=".csv,.xlsx,.xls,.txt"
        onChange={(event) =>
          event.target.files?.[0] && onFile(event.target.files[0])
        }
      />
      {!rows.length ? (
        <button
          onClick={() => fileRef.current?.click()}
          className="flex min-h-64 w-full flex-col items-center justify-center rounded-[26px] bg-white p-7 text-center shadow-[0_6px_28px_rgba(72,63,82,.05)] transition hover:bg-[#FDFBFF]"
        >
          <span className="grid size-16 place-items-center rounded-[20px] bg-[#F1EDF8] text-[#796CAD]">
            <Upload className="size-7" />
          </span>
          <strong className="mt-5 text-lg font-medium">选择词表文件</strong>
          <span className="mt-2 text-sm text-[#8A858E]">
            单次最多 2000 词；确认前不会写入词库
          </span>
        </button>
      ) : (
        <div className="space-y-4">
          <div className="rounded-[24px] bg-white p-5 shadow-[0_6px_24px_rgba(72,63,82,.05)]">
            <div className="flex items-center justify-between gap-3">
              <div className="min-w-0">
                <p className="truncate font-medium">{fileName}</p>
                <p className="mt-1 text-sm text-[#8A858E]">
                  解析完成，请确认重复项的处理方式
                </p>
              </div>
              <Button variant="outline" onClick={() => fileRef.current?.click()}>
                换文件
              </Button>
            </div>
            <div className="mt-5 grid grid-cols-4 gap-2">
              <MiniStat label="识别" value={stats.recognized} />
              <MiniStat label="新增" value={stats.added} />
              <MiniStat label="重复" value={stats.duplicate} />
              <MiniStat label="问题" value={stats.issues} warn={stats.issues > 0} />
            </div>
          </div>

          <div className="space-y-3">
            {rows.slice(0, 100).map((row, index) => (
              <div
                key={row.key}
                className={`rounded-[20px] bg-white p-4 shadow-[0_3px_16px_rgba(72,63,82,.04)] ${row.issue ? "ring-1 ring-[#F3D7D4]" : row.duplicate ? "ring-1 ring-[#EEE1B9]" : ""}`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <strong lang="ja" className="text-lg font-medium">
                      {row.word || "（缺少单词）"}
                    </strong>
                    <p lang="ja" className="text-sm text-[#817C85]">
                      {row.reading || "（缺少读音）"}
                    </p>
                    <p className="mt-2 text-sm">{row.meaning || "（缺少释义）"}</p>
                    {row.exampleJa && (
                      <p lang="ja" className="mt-2 text-sm text-[#736A86]">
                        {row.exampleJa}
                      </p>
                    )}
                  </div>
                  <span className="text-xs text-[#A29DA5]">#{index + 1}</span>
                </div>
                {row.issue && (
                  <p className="mt-3 flex items-center gap-1 text-sm text-[#A85852]">
                    <CircleAlert className="size-4" />
                    {row.issue}，将跳过
                  </p>
                )}
                {row.duplicate && !row.issue && (
                  <div className="mt-3 rounded-2xl bg-[#FFF9EA] p-3">
                    <p className="mb-2 text-xs text-[#817044]">
                      原释义：{row.duplicate.meaning}
                    </p>
                    <Select
                      value={row.action}
                      onValueChange={(value) =>
                        onRows(
                          rows.map((item) =>
                            item.key === row.key
                              ? { ...item, action: value as ImportRow["action"] }
                              : item,
                          ),
                        )
                      }
                    >
                      <SelectTrigger className="w-full bg-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="keep">保留原词</SelectItem>
                        <SelectItem value="update">更新释义和例句</SelectItem>
                        <SelectItem value="skip">取消导入此词</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>
            ))}
          </div>

          {rows.length > 100 && (
            <p className="text-center text-sm text-[#8A858E]">
              预览前 100 行，其余内容会按相同规则导入
            </p>
          )}
          <Button
            disabled={
              importing ||
              !rows.some((row) => !row.issue && row.action !== "skip")
            }
            onClick={onConfirm}
            className="h-12 w-full rounded-2xl bg-[#8577B9] text-base font-medium shadow-none hover:bg-[#776AA9]"
          >
            {importing ? "正在导入…" : "确认并正式导入"}
          </Button>
        </div>
      )}
    </PageShell>
  );
}

function MiniStat({
  label,
  value,
  warn,
}: {
  label: string;
  value: number;
  warn?: boolean;
}) {
  return (
    <div
      className={`rounded-2xl p-3 text-center ${warn ? "bg-[#FFF1F0] text-[#9A514C]" : "bg-[#F7F5F8]"}`}
    >
      <strong className="block text-lg font-semibold">{value}</strong>
      <span className="text-xs">{label}</span>
    </div>
  );
}

function WordList({
  title,
  description,
  words,
  search,
  setSearch,
  onEdit,
  onDelete,
  onFocus,
  focusOnly,
  onTrain,
}: {
  title: string;
  description: string;
  words: Word[];
  search: string;
  setSearch: (value: string) => void;
  onEdit: (word: Word) => void;
  onDelete: (word: Word) => void;
  onFocus: (word: Word) => void;
  focusOnly?: boolean;
  onTrain?: () => void;
}) {
  return (
    <PageShell
      eyebrow={focusOnly ? "听力薄弱词" : "词库管理"}
      title={title}
      description={description}
      action={
        focusOnly && words.length ? (
          <Button
            onClick={onTrain}
            className="bg-[#8577B9] shadow-none hover:bg-[#776AA9]"
          >
            <Play className="fill-current" />
            只复习重点词
          </Button>
        ) : undefined
      }
    >
      <div className="relative mb-4">
        <Search className="absolute left-3.5 top-1/2 size-5 -translate-y-1/2 text-[#9B96A0]" />
        <Input
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          placeholder="搜索单词、读音或释义"
          className="h-12 rounded-2xl border-0 bg-white pl-11 text-base shadow-[0_3px_14px_rgba(72,63,82,.045)]"
        />
        {search && (
          <button
            aria-label="清空搜索"
            onClick={() => setSearch("")}
            className="absolute right-3 top-1/2 -translate-y-1/2"
          >
            <X className="size-5" />
          </button>
        )}
      </div>

      {!words.length ? (
        <div className="rounded-[26px] bg-white p-10 text-center shadow-[0_4px_18px_rgba(72,63,82,.04)]">
          <BookOpen className="mx-auto size-9 text-[#A7A1AC]" />
          <h3 className="mt-4 font-medium">
            {focusOnly ? "还没有重点词" : "词库中还没有内容"}
          </h3>
          <p className="mt-2 text-sm text-[#8A858E]">
            {focusOnly
              ? "训练中选择“模糊”或“完全不会”后会自动加入。"
              : "先添加或导入几个日语单词。"}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {words.map((word) => (
            <WordCard
              key={word.id}
              word={word}
              onEdit={onEdit}
              onDelete={onDelete}
              onFocus={onFocus}
            />
          ))}
        </div>
      )}
    </PageShell>
  );
}

function WordCard({
  word,
  onEdit,
  onDelete,
  onFocus,
}: {
  word: Word;
  onEdit: (word: Word) => void;
  onDelete: (word: Word) => void;
  onFocus: (word: Word) => void;
}) {
  const weak =
    word.missedCount >= word.fuzzyCount && word.missedCount > 0
      ? "missed"
      : word.fuzzyCount > 0
        ? "fuzzy"
        : null;

  return (
    <article className="rounded-[22px] bg-white p-4 shadow-[0_4px_18px_rgba(72,63,82,.045)] sm:p-5">
      <div className="flex items-start gap-3">
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <h3 lang="ja" className="text-xl font-semibold text-[#48444C]">
              {word.word}
            </h3>
            {word.isFocus && (
              <span
                className={`rounded-full px-2.5 py-1 text-xs ${weak === "missed" ? "bg-[#FFF0EF] text-[#9E514B]" : "bg-[#FFF8E6] text-[#8C7542]"}`}
              >
                {weak === "missed" ? "重点 · 完全不会为主" : "重点 · 模糊为主"}
              </span>
            )}
          </div>
          <p lang="ja" className="mt-0.5 text-sm text-[#817C85]">
            {word.reading}
          </p>
          <p className="mt-3 leading-relaxed text-[#555159]">{word.meaning}</p>
        </div>
        <div className="flex shrink-0 gap-1">
          <Button
            size="icon-sm"
            variant="ghost"
            aria-label={`编辑 ${word.word}`}
            onClick={() => onEdit(word)}
          >
            <Pencil />
          </Button>
          <Button
            size="icon-sm"
            variant="ghost"
            aria-label={`删除 ${word.word}`}
            onClick={() => onDelete(word)}
          >
            <Trash2 />
          </Button>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-3 gap-2 text-center text-xs">
        <Count label="会" value={word.knewCount} tone="green" />
        <Count label="模糊" value={word.fuzzyCount} tone="yellow" />
        <Count label="不会" value={word.missedCount} tone="red" />
      </div>
      <div className="mt-4 flex flex-wrap items-center justify-between gap-2 border-t border-[#F0EDF2] pt-3">
        <span className="flex items-center gap-1.5 text-xs text-[#918C95]">
          <Clock3 className="size-3.5" />
          {formatDate(word.lastReviewedAt)}
        </span>
        <Button size="sm" variant="ghost" onClick={() => void onFocus(word)}>
          {word.isFocus ? (
            <>
              <X />移出重点
            </>
          ) : (
            <>
              <Star />加入重点
            </>
          )}
        </Button>
      </div>
    </article>
  );
}

function Count({
  label,
  value,
  tone,
}: {
  label: string;
  value: number;
  tone: "green" | "yellow" | "red";
}) {
  const tones = {
    green: "bg-[#EFF8F2] text-[#557861]",
    yellow: "bg-[#FFF8E8] text-[#846F42]",
    red: "bg-[#FFF1F0] text-[#99544E]",
  };
  return (
    <div className={`rounded-xl px-2 py-2.5 ${tones[tone]}`}>
      <strong className="font-semibold">{value}</strong>
      <span className="ml-1">{label}</span>
    </div>
  );
}

function TrainingScreen({
  mode,
  phase,
  current,
  activeCount,
  played,
  rated,
  rating,
  audioStatus,
  ttsError,
  onBack,
  onPlay,
  onRate,
  onNext,
}: {
  mode: TrainingMode;
  phase: TrainingPhase;
  current: Word | null;
  activeCount: number;
  played: boolean;
  rated: Result | null;
  rating: boolean;
  audioStatus: "idle" | "playing";
  ttsError: string;
  onBack: () => void;
  onPlay: () => void;
  onRate: (result: Result) => void;
  onNext: () => void;
}) {
  if (!current) {
    return (
      <div className="min-h-dvh bg-[#FAF9F7] text-[#464249]">
        <Toaster position="top-center" richColors />
        <main className="mx-auto flex min-h-dvh max-w-xl flex-col items-center justify-center px-6 text-center">
          <span className="grid size-20 place-items-center rounded-full bg-[#F0ECF8] text-[#7D70AD]">
            <Check className="size-8" />
          </span>
          <h1 className="mt-6 text-2xl font-semibold">这一轮完成了</h1>
          <p className="mt-3 max-w-xs leading-relaxed text-[#85808A]">
            已会的词暂时移出本轮；其余词会在之后继续穿插复习。
          </p>
          <Button
            onClick={onBack}
            className="mt-8 h-12 rounded-2xl bg-[#8577B9] px-8 font-medium shadow-none hover:bg-[#776AA9]"
          >
            返回首页
          </Button>
        </main>
      </div>
    );
  }

  const example = exampleFor(current);

  return (
    <div className="min-h-dvh bg-[#FAF9F7] text-[#464249]">
      <Toaster position="top-center" richColors />
      <header className="mx-auto flex h-16 max-w-xl items-center justify-between px-4">
        <Button
          variant="ghost"
          onClick={onBack}
          className="text-[#706B74] hover:bg-[#F0EDF3]"
        >
          <ArrowLeft />结束
        </Button>
        <span className="text-sm text-[#918B95]">
          {mode === "focus" ? "重点复习" : "普通复习"} · 当前池 {activeCount}
        </span>
        <span className="w-16" />
      </header>

      {phase === "listen" ? (
        <main className="mx-auto flex min-h-[calc(100dvh-64px)] max-w-xl flex-col px-5 pb-[max(2rem,env(safe-area-inset-bottom))]">
          <section className="flex flex-1 flex-col items-center justify-center py-10 text-center">
            <p className="mb-9 text-sm text-[#97919B]">
              只听声音，想一想它的意思
            </p>
            <button
              onClick={onPlay}
              className="group grid size-48 place-items-center rounded-full bg-white shadow-[0_18px_55px_rgba(87,73,108,.09)] transition active:scale-[.97]"
              aria-label={played ? "再听一次日语发音" : "播放日语发音"}
            >
              <span className="grid size-28 place-items-center rounded-full bg-[#EEE9F8] text-[#786BAD] transition group-hover:bg-[#E8E1F5]">
                <Volume2 className="size-11" strokeWidth={1.7} />
              </span>
            </button>
            <p className="mt-7 font-medium text-[#625D66]">
              {audioStatus === "playing"
                ? "正在播放…"
                : played
                  ? "再听一次"
                  : "播放发音"}
            </p>
            {ttsError && (
              <p
                role="alert"
                className="mt-5 max-w-sm rounded-2xl bg-[#FFF0EF] p-3 text-sm leading-relaxed text-[#98514C]"
              >
                {ttsError}
              </p>
            )}
          </section>

          <section>
            <p className="mb-3 text-center text-sm text-[#918B95]">
              你的第一反应是？
            </p>
            <div className="grid grid-cols-3 gap-2.5">
              <RatingButton
                label="会"
                tone="green"
                disabled={!played || rating}
                onClick={() => onRate("knew")}
              />
              <RatingButton
                label="模糊"
                tone="yellow"
                disabled={!played || rating}
                onClick={() => onRate("fuzzy")}
              />
              <RatingButton
                label="完全不会"
                tone="red"
                disabled={!played || rating}
                onClick={() => onRate("missed")}
              />
            </div>
            {rating && (
              <p className="mt-3 text-center text-sm text-[#918B95]">
                正在保存本次判断…
              </p>
            )}
          </section>
        </main>
      ) : (
        <main className="mx-auto flex min-h-[calc(100dvh-64px)] max-w-xl flex-col px-5 pb-[max(2rem,env(safe-area-inset-bottom))] pt-5">
          <section className="flex flex-1 flex-col rounded-[30px] bg-white px-6 py-8 shadow-[0_12px_40px_rgba(75,64,88,.065)] sm:px-8">
            <div className="flex items-start justify-between gap-4">
              <div className="min-w-0">
                <p lang="ja" className="text-[2.6rem] font-semibold leading-tight tracking-[-0.035em] text-[#403C44]">
                  {current.word}
                </p>
                <p lang="ja" className="mt-2 text-xl font-normal text-[#817B85]">
                  {current.reading}
                </p>
              </div>
              <button
                onClick={onPlay}
                className="grid size-11 shrink-0 place-items-center rounded-full bg-[#F1EDF8] text-[#7568A7] transition hover:bg-[#E9E3F4] active:scale-95"
                aria-label="再次播放当前单词"
              >
                <Volume2 className="size-5" />
              </button>
            </div>

            <p className="mt-8 text-xl font-normal leading-relaxed text-[#514D55]">
              {current.meaning}
            </p>

            <div className="my-8 h-px bg-[#F0EDF2]" />

            <div>
              <p className="text-xs tracking-[0.12em] text-[#9A949E]">例句</p>
              <p lang="ja" className="mt-3 text-lg font-normal leading-[1.8] text-[#514D55]">
                {example.ja}
              </p>
              <p className="mt-2 text-base font-normal leading-relaxed text-[#8A858E]">
                {example.zh}
              </p>
            </div>

            {ttsError && (
              <p
                role="alert"
                className="mt-6 rounded-2xl bg-[#FFF0EF] p-3 text-sm text-[#98514C]"
              >
                {ttsError}
              </p>
            )}

            <div className="mt-auto pt-8">
              <span className="inline-flex rounded-full bg-[#F5F2F8] px-3 py-1.5 text-xs text-[#746E79]">
                本次：{rated ? resultLabel[rated] : ""}
              </span>
            </div>
          </section>

          <Button
            onClick={onNext}
            className="mt-4 h-14 w-full rounded-2xl bg-[#8577B9] text-base font-medium shadow-none hover:bg-[#776AA9]"
          >
            下一词 <ChevronRight />
          </Button>
        </main>
      )}
    </div>
  );
}

function RatingButton({
  label,
  tone,
  disabled,
  onClick,
}: {
  label: string;
  tone: "green" | "yellow" | "red";
  disabled: boolean;
  onClick: () => void;
}) {
  const tones = {
    green: "bg-[#EDF7F0] text-[#567561] hover:bg-[#E5F1E9]",
    yellow: "bg-[#FFF7E3] text-[#806D42] hover:bg-[#FBEFCE]",
    red: "bg-[#FFF0EF] text-[#96514B] hover:bg-[#F8E5E3]",
  };
  return (
    <button
      disabled={disabled}
      onClick={onClick}
      className={`min-h-20 rounded-[18px] px-2 py-3 font-medium transition disabled:cursor-not-allowed disabled:opacity-35 ${tones[tone]}`}
    >
      {label}
    </button>
  );
}

function PageShell({
  eyebrow,
  title,
  description,
  action,
  children,
}: {
  eyebrow: string;
  title: string;
  description: string;
  action?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <div>
      <div className="mb-7 flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-sm font-medium text-[#7B6EAD]">{eyebrow}</p>
          <h1 className="mt-1 text-3xl font-semibold tracking-[-0.025em] text-[#454149]">
            {title}
          </h1>
          <p className="mt-2 max-w-xl leading-relaxed text-[#817C85]">
            {description}
          </p>
        </div>
        {action}
      </div>
      {children}
    </div>
  );
}

function EditDialog({
  word,
  onClose,
  onSave,
}: {
  word: Word | null;
  onClose: () => void;
  onSave: (id: number, draft: Draft) => void;
}) {
  const [value, setValue] = useState<Draft>(EMPTY);
  useEffect(() => {
    if (word) {
      setValue({
        word: word.word,
        reading: word.reading,
        meaning: word.meaning,
        exampleJa: word.exampleJa || "",
        exampleZh: word.exampleZh || "",
      });
    }
  }, [word]);

  return (
    <Dialog open={Boolean(word)} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-h-[88dvh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>编辑单词</DialogTitle>
          <DialogDescription>
            修改后仍会检查“日语单词 + 读音”的唯一性。
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <Field
            label="日语单词"
            value={value.word}
            placeholder=""
            onChange={(wordValue) => setValue({ ...value, word: wordValue })}
            lang="ja"
          />
          <Field
            label="假名 / 读音"
            value={value.reading}
            placeholder=""
            onChange={(reading) => setValue({ ...value, reading })}
            lang="ja"
          />
          <div className="space-y-2">
            <Label>中文释义</Label>
            <Textarea
              value={value.meaning}
              onChange={(event) =>
                setValue({ ...value, meaning: event.target.value })
              }
              className="min-h-24 rounded-2xl"
            />
          </div>
          <Field
            label="日语例句"
            value={value.exampleJa}
            placeholder=""
            onChange={(exampleJa) => setValue({ ...value, exampleJa })}
            lang="ja"
            required={false}
          />
          <Field
            label="例句中文"
            value={value.exampleZh}
            placeholder=""
            onChange={(exampleZh) => setValue({ ...value, exampleZh })}
            required={false}
          />
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            取消
          </Button>
          <Button onClick={() => word && onSave(word.id, value)}>保存修改</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function BottomNav({
  view,
  onNavigate,
}: {
  view: View;
  onNavigate: (view: View) => void;
}) {
  const items: { view: View; label: string; icon: React.ReactNode }[] = [
    { view: "home", label: "首页", icon: <House /> },
    { view: "add", label: "添加", icon: <Plus /> },
    { view: "library", label: "词库", icon: <Library /> },
    { view: "focus", label: "重点", icon: <Star /> },
  ];

  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-[#EEEAF0] bg-white/90 px-2 pb-[max(.5rem,env(safe-area-inset-bottom))] pt-2 backdrop-blur-xl sm:hidden">
      <div className="grid grid-cols-4">
        {items.map((item) => (
          <button
            key={item.view}
            onClick={() => onNavigate(item.view)}
            className={`flex min-h-14 flex-col items-center justify-center gap-1 rounded-2xl text-xs ${view === item.view ? "bg-[#F1EDF8] font-medium text-[#7467A5]" : "text-[#8B858F]"}`}
          >
            {item.icon}
            {item.label}
          </button>
        ))}
      </div>
    </nav>
  );
}
