import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Hibiki",
  description: "先听见，再想起来。轻盈专注的日语听力词汇训练。",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN">
      <body className="antialiased">{children}</body>
    </html>
  );
}
