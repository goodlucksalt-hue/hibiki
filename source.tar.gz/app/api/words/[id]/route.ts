import { getWordStore, type WordPatch } from "../../../../db/store";

const parseId = async (params: Promise<{ id: string }>) => Number((await params).id);

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const id = await parseId(params);
    if (!Number.isInteger(id)) return Response.json({ error: "无效编号" }, { status: 400 });
    const payload = (await request.json()) as { word?: string; reading?: string; meaning?: string; exampleJa?: string; exampleZh?: string; isFocus?: boolean };
    const update: WordPatch = {};
    if (typeof payload.word === "string") update.word = payload.word.trim();
    if (typeof payload.reading === "string") update.reading = payload.reading.trim();
    if (typeof payload.meaning === "string") update.meaning = payload.meaning.trim();
    if (typeof payload.exampleJa === "string") update.exampleJa = payload.exampleJa.trim();
    if (typeof payload.exampleZh === "string") update.exampleZh = payload.exampleZh.trim();
    if (typeof payload.isFocus === "boolean") update.isFocus = payload.isFocus;
    if (("word" in update && !update.word) || ("reading" in update && !update.reading) || ("meaning" in update && !update.meaning)) {
      return Response.json({ error: "单词、读音和释义不能为空。" }, { status: 400 });
    }
    const updated = await (await getWordStore()).update(id, update);
    return updated ? Response.json({ word: updated }) : Response.json({ error: "未找到这个词。" }, { status: 404 });
  } catch (error) {
    console.error("words.PATCH", error);
    return Response.json({ error: "更新失败，可能与现有词重复。" }, { status: 500 });
  }
}

export async function DELETE(_: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const id = await parseId(params);
    await (await getWordStore()).remove(id);
    return Response.json({ ok: true });
  } catch (error) {
    console.error("words.DELETE", error);
    return Response.json({ error: "删除失败，请重试。" }, { status: 500 });
  }
}
