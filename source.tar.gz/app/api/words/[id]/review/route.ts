import { getWordStore } from "../../../../../db/store";

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const id = Number((await params).id);
    const { result } = (await request.json()) as { result?: "knew" | "fuzzy" | "missed" };
    if (!Number.isInteger(id) || !result || !["knew", "fuzzy", "missed"].includes(result)) {
      return Response.json({ error: "复习结果无效。" }, { status: 400 });
    }
    const updated = await (await getWordStore()).recordReview(id, result);
    return updated ? Response.json({ word: updated }) : Response.json({ error: "未找到这个词。" }, { status: 404 });
  } catch (error) {
    console.error("words.review", error);
    return Response.json({ error: "复习结果未能保存，请重试。" }, { status: 500 });
  }
}
