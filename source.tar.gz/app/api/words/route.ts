import { getWordStore } from "../../../db/store";

const clean = (value: unknown) => (typeof value === "string" ? value.trim() : "");

export async function GET() {
  try {
    const rows = await (await getWordStore()).list();
    return Response.json({ words: rows });
  } catch (error) {
    console.error("words.GET", error);
    return Response.json({ error: "词库暂时无法读取，请稍后重试。" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const payload = (await request.json()) as Record<string, unknown>;
    const word = clean(payload.word);
    const reading = clean(payload.reading);
    const meaning = clean(payload.meaning);
    const exampleJa = clean(payload.exampleJa);
    const exampleZh = clean(payload.exampleZh);
    const duplicateAction = clean(payload.duplicateAction);
    if (!word || !reading || !meaning) {
      return Response.json({ error: "请完整填写单词、读音和释义。" }, { status: 400 });
    }
    const store = await getWordStore();
    const existing = await store.findDuplicate(word, reading);
    if (existing) {
      if (existing.meaning === meaning || duplicateAction === "keep") {
        return Response.json({ code: "duplicate", word: existing }, { status: 409 });
      }
      if (duplicateAction === "update") {
        const updated = await store.update(existing.id, { meaning, exampleJa, exampleZh });
        return Response.json({ word: updated, updated: true });
      }
      return Response.json({ code: "duplicate_conflict", existing }, { status: 409 });
    }
    const created = await store.create({ word, reading, meaning, exampleJa, exampleZh });
    return Response.json({ word: created }, { status: 201 });
  } catch (error) {
    console.error("words.POST", error);
    return Response.json({ error: "保存失败，请保留输入并重试。" }, { status: 500 });
  }
}
