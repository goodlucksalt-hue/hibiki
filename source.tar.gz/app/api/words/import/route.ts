import { getWordStore } from "../../../../db/store";

type ImportRow = { word?: string; reading?: string; meaning?: string; exampleJa?: string; exampleZh?: string; action?: "keep" | "update" | "skip" };

export async function POST(request: Request) {
  try {
    const payload = (await request.json()) as { rows?: ImportRow[] };
    if (!Array.isArray(payload.rows) || payload.rows.length > 2000) {
      return Response.json({ error: "导入内容无效，单次最多 2000 词。" }, { status: 400 });
    }
    const store = await getWordStore();
    let added = 0;
    let updated = 0;
    let skipped = 0;
    for (const raw of payload.rows) {
      const word = raw.word?.trim() ?? "";
      const reading = raw.reading?.trim() ?? "";
      const meaning = raw.meaning?.trim() ?? "";
      const exampleJa = raw.exampleJa?.trim() ?? "";
      const exampleZh = raw.exampleZh?.trim() ?? "";
      if (!word || !reading || !meaning || raw.action === "skip") {
        skipped += 1;
        continue;
      }
      const existing = await store.findDuplicate(word, reading);
      if (existing) {
        if (raw.action === "update" && existing.meaning !== meaning) {
          await store.update(existing.id, { meaning, exampleJa, exampleZh });
          updated += 1;
        } else skipped += 1;
      } else {
        await store.create({ word, reading, meaning, exampleJa, exampleZh });
        added += 1;
      }
    }
    return Response.json({ added, updated, skipped });
  } catch (error) {
    console.error("words.import", error);
    return Response.json({ error: "导入写入失败，请重试。" }, { status: 500 });
  }
}
